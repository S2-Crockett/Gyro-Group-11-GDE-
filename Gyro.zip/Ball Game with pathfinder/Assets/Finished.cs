﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Finished : MonoBehaviour
{
    public Transform player;
    public Transform goal;
    public float distance;
    public GameObject finishMenuUI;

    void Update()
    {
        distance = Vector3.Distance(player.transform.position, goal.transform.position);
        if (distance < 15)
        {
            finishMenuUI.SetActive(true);
        }
    }
}
