﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lose : MonoBehaviour
{
    public Transform enemy;
    public Transform goal;
    public float distance;
    public GameObject loseMenuUI;
    public Timer gT;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        distance = Vector3.Distance(enemy.transform.position, goal.transform.position);
        if (distance < 3)
        {
            loseMenuUI.SetActive(true);
            Time.timeScale = 0f;
            gT.paused = true;
        }
    }
}
