﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spikes : MonoBehaviour
{

    public Animator Spike;
    public Transform player;
    public Transform respawn;

    public float random;
    public float Random_gen;

    private bool hit = false;

    void Start()
    {
        random = 0;
    }


    void Update()
    {
        Random_gen = Random.value;
        random += Time.deltaTime;
        if (random > 5)
        {
            random = 0;
            Random_gen = 0;
        }
        if (Random_gen > random)
        {
            if (Spike.GetCurrentAnimatorStateInfo(0).normalizedTime > 1 && !Spike.IsInTransition(0))
            {
                Spike.SetBool("Activated", true);
            }
        }
        else if (Random_gen < random)
        {
            Spike.SetBool("Activated", false);
        }

        if (hit == true)
        {
            player.transform.position = respawn.transform.position;
            hit = false;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hit = true;
        }
    }
}
