﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Holes : MonoBehaviour
{
    public Transform player;
    public Transform hole;
    public Transform respawn;

    public bool falling = false;
    public float distance;

    
    void Start()
    {
        
    }
    void Update()
    {
        distance = Vector3.Distance(player.transform.position, hole.transform.position);


        if (distance < 10)
        {
            falling = true;
        }

        if (falling == true)
        {

            player.GetComponent<SphereCollider>().isTrigger = true;
            player.GetComponent<Rigidbody>().useGravity = true;
            player.GetComponent<Rigidbody>().mass = 100;
            player.GetComponent<Rigidbody>().drag = 2;

            if (player.transform.position.y < -13)
            {
                falling = false;
                player.transform.position = respawn.transform.position;
                player.GetComponent<SphereCollider>().isTrigger = false;
                player.GetComponent<Rigidbody>().useGravity = false;
                player.GetComponent<Rigidbody>().mass = 1;
                player.GetComponent<Rigidbody>().drag = 1;
            }
        }
    }


}
