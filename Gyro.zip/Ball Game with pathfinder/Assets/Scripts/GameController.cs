﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public Animator animGreen;
    public Animator animGreen_two;
    public Animator animBlue;
    public Animator animBlue_two;
    public Animator animRed;
    public Animator animRed_two;
    public void CloseGreenDoor()
    {
        animGreen.SetTrigger("PressedGreen");
        animGreen_two.SetTrigger("PressedGreen");
    }

    public void CloseBlueDoor()
    {
        animBlue.SetTrigger("PressedBlue");
        animBlue_two.SetTrigger("PressedBlue");
    }

    public void CloseRedDoor()
    {
        animRed.SetTrigger("PressedRed");
        animRed_two.SetTrigger("PressedRed");
    }
}
