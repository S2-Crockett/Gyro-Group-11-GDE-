﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour
{
    private float destinationX;
    private float destinationY;
    Vector3 dest;
    public GameObject destination;
    public NavMeshAgent agent;

    private void Awake()
    {
        destinationX = destination.transform.position.x;
        destinationY = destination.transform.position.y;
        dest = new Vector3(destinationX, destinationY); 
    }
    private void FixedUpdate()
    {

        agent.SetDestination(dest);
    }
}
