﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class TriggerEvents : MonoBehaviour
{

    public GameController controller;
    public NavMeshSurface mesh;
    public GameObject winMenuUI;

    private bool redClosed = false;
    private bool greenClosed = false;
    private bool blueClosed = false;

    void Update()
    {
        if (!redClosed || !greenClosed || !blueClosed)
        {
            Time.timeScale = 1f;
        }
        if (redClosed && greenClosed && blueClosed)
        {
            winMenuUI.SetActive(true);
            Time.timeScale = 0f;
        }
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("GreenButton"))
        {
            controller.CloseGreenDoor();
            greenClosed = true;
        }
        else if (other.CompareTag("BlueButton"))
        {
            controller.CloseBlueDoor();
            blueClosed = true;
        }
        else if (other.CompareTag("RedButton"))
        {
            controller.CloseRedDoor();
            redClosed = true;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        
        if (other.CompareTag("GreenButton"))
        {
            mesh.BuildNavMesh();
        }       
        if (other.CompareTag("BlueButton"))
        {
            mesh.BuildNavMesh();
        }
        if (other.CompareTag("RedButton"))
        {
            mesh.BuildNavMesh();
        }


    }


}
